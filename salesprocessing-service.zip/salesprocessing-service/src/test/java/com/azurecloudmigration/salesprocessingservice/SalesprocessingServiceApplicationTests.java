package com.azurecloudmigration.salesprocessingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesprocessingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
